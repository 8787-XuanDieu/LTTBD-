import 'package:flutter/material.dart';

class BMI extends StatefulWidget {
  @override
  _BMIState createState() => _BMIState();
}

class _BMIState extends State<BMI> {
  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();
  String _result = '';

  void _calculateBMI() {
    final double? weight = double.tryParse(_weightController.text);
    final double? height = double.tryParse(_heightController.text);

    if (weight == null || weight <= 0 || height == null || height <= 0) {
      setState(() {
        _result = 'Vui lòng nhập giá trị cân nặng và chiều cao hợp lệ.';
      });
      return;
    }

    final double bmi = weight / (height * height);

    if (bmi < 18.5) {
      setState(() {
        _result = 'Chỉ số BMI: ${bmi.toStringAsFixed(1)}\nBạn đang ở trạng thái nhẹ cân.';
      });
    } else if (bmi >= 18.5 && bmi < 24.9) {
      setState(() {
        _result = 'Chỉ số BMI: ${bmi.toStringAsFixed(1)}\nBạn có cân nặng bình thường.';
      });
    } else if (bmi >= 25 && bmi < 29.9) {
      setState(() {
        _result = 'Chỉ số BMI: ${bmi.toStringAsFixed(1)}\nBạn đang thừa cân.';
      });
    } else {
      setState(() {
        _result = 'Chỉ số BMI: ${bmi.toStringAsFixed(1)}\nBạn đang béo phì.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tính toán BMI'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _weightController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Nhập cân nặng (kg)',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: _heightController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Nhập chiều cao (m)',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: _calculateBMI,
              child: Text('Tính toán'),
            ),
            SizedBox(height: 16),
            Text(
              _result,
              style: TextStyle(fontSize: 18, color: Colors.blue),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
