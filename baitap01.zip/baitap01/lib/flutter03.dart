import 'package:flutter/material.dart';

class temp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chuyển đổi nhiệt độ'),
        backgroundColor: Colors.blue,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(1.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [

              TextField(
                decoration: InputDecoration(
                  labelText: 'Nhiệt độ C',
                  border: OutlineInputBorder()
                ),
        ),
                  SizedBox(height: 20), // Khoảng cách giữa các TextField
                  TextField(
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Nhiệt độ T',
                    ),
                  ),

            ],

          ),
          
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          print('Ban da nhan vao nut Alarm');
        },
        child: Icon(Icons.access_alarm),
      ),
    );
  }
}
